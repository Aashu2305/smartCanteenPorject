package com.example.smart_canteen_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartCanteenBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
