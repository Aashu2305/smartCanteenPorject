package com.example.smart_canteen_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartCanteenBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartCanteenBackendApplication.class, args);
	}

}
